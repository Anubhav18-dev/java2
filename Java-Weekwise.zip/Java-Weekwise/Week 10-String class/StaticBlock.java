class StaticBlock{
        static int y;
	public static void main(String s[])
	{
	System.out.println("Hi");
	}

	static{
        int x=10;
        y=20;
	System.out.println("Hello Java1"+x);
	}
        public void display()
	{
		System.out.println();
	}

}

	