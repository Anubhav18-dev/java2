class StringCommandLine1{

public static void main(String s[])
{

int i= Integer.parseInt(s[0]);
System.out.println( "i="+i);

}
}