class abc
 {
	public static void main(String args[])
	{
	String s1="Hello";
	System.out.println(s1);
	s1="hello world";
	System.out.println(s1);
	}
	}