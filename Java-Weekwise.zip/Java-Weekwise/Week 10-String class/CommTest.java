class CommTest{
	public static void main( String s[])
        {
		int num=Integer.parseInt(s[0]);
                System.out.println(num);
               

	}

}


